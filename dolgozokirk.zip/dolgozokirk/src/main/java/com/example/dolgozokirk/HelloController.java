package com.example.dolgozokirk;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class HelloController {
    private static final Locale HU = Locale.forLanguageTag("hu-HU");

    // ---------- Fájl betöltés ----------
    @FXML private TextField fajlTextField;          // ÚJ – "dolgozok.txt"
    @FXML private Label betoltesLabel;              // ÚJ – "24 dolgozó sikeresen betöltve"

    // ---------- Új dolgozó ----------
    @FXML private TextField ujNevTextField;         // ÚJ
    @FXML private TextField ujReszlegTextField;     // ÚJ
    @FXML private TextField ujBerTextField;         // ÚJ
    @FXML private CheckBox ujTeljesCheckbox;        // ÚJ
    @FXML private Label mentesLabel;                // ÚJ – "A mentés állapota itt jelenik meg."

    // ---------- Keresés és szűrés ----------
    @FXML private TextField nevReszletTextField;    // ÚJ – "Név részlete"
    @FXML private RadioButton osszesRadio;          // ÚJ
    @FXML private RadioButton ber0Radio;            // ÚJ – 0–399 999
    @FXML private RadioButton ber400Radio;          // ÚJ – 400 000–599 999
    @FXML private RadioButton ber600Radio;          // ÚJ – 600 000–799 999
    @FXML private RadioButton ber800Radio;          // ÚJ – legalább 800 000
    @FXML private CheckBox munkaidoSzuresCheckbox;
    @FXML private Button elozoButton;               // ÚJ
    @FXML private Button kovetkezoButton;           // ÚJ

    // ---------- Megjelenítés ----------
    @FXML private Label keresNevLabel;              // "Horváth Hanna"
    @FXML private Label kerestalalatLabel;          // "2 / 4"
    @FXML private Label keresReszlegLabel;          // "Pénzügy"
    @FXML private Label keresBerLabel;              // "500 000 Ft"
    @FXML private Label keresMunkaidoLabel;         // "Teljes"
    @FXML private Label keresTalalatLabel;          // "4 fő"
    @FXML private Label keresAtlagBerLabel;         // "504 999,75 Ft"
    @FXML private Label keresLegmagasabbBerLabel;   // "599 999 Ft"

    private final List<Dolgozo> dolgozok = new ArrayList<>();
    private List<Dolgozo> talalatok = new ArrayList<>();
    private int index = 0;

    @FXML
    private void initialize() {
        // a rádiógombok egy csoportba kerülnek, így egyszerre csak egy lehet bejelölve
        ToggleGroup csoport = new ToggleGroup();
        osszesRadio.setToggleGroup(csoport);
        ber0Radio.setToggleGroup(csoport);
        ber400Radio.setToggleGroup(csoport);
        ber600Radio.setToggleGroup(csoport);
        ber800Radio.setToggleGroup(csoport);
        osszesRadio.setSelected(true);
        frissit();
    }

    // ---------- Betöltés gomb ----------
    @FXML
    protected void onBetoltClicked() {
        dolgozok.clear();
        try {
            for (String sor : Files.readAllLines(Path.of(fajlTextField.getText().trim()), StandardCharsets.UTF_8)) {
                if (sor.isBlank()) continue;
                try {
                    dolgozok.add(Dolgozo.feldolgoz(sor));
                } catch (RuntimeException e) {
                    // fejléc vagy hibás sor – kihagyjuk
                }
            }
            betoltesLabel.setText(dolgozok.size() + " dolgozó sikeresen betöltve");
        } catch (IOException e) {
            betoltesLabel.setText("Hiba: a fájl nem olvasható (" + fajlTextField.getText() + ")");
        }
        onKeresClicked();
    }

    // ---------- Szűrés gomb ----------
    @FXML
    protected void onKeresClicked() {
        String resz = nevReszletTextField.getText().trim().toLowerCase();
        talalatok = new ArrayList<>();
        for (Dolgozo d : dolgozok) {
            if (!d.getNev().toLowerCase().contains(resz)) continue;
            if (munkaidoSzuresCheckbox.isSelected() && !d.isTeljes()) continue;
            if (!berMegfelel(d.getBer())) continue;
            talalatok.add(d);
        }
        index = 0;
        frissit();
    }

    private boolean berMegfelel(int ber) {
        if (ber0Radio.isSelected())   return ber < 400_000;
        if (ber400Radio.isSelected()) return ber >= 400_000 && ber < 600_000;
        if (ber600Radio.isSelected()) return ber >= 600_000 && ber < 800_000;
        if (ber800Radio.isSelected()) return ber >= 800_000;
        return true; // Összes
    }

    // ---------- Mentés gomb ----------
    @FXML
    protected void onMentesClicked() {
        String nev = ujNevTextField.getText().trim();
        String reszleg = ujReszlegTextField.getText().trim();
        if (nev.isEmpty() || reszleg.isEmpty()) {
            mentesLabel.setText("A név és a részleg megadása kötelező.");
            return;
        }
        int ber;
        try {
            ber = Integer.parseInt(ujBerTextField.getText().trim());
        } catch (NumberFormatException e) {
            ber = -1;
        }
        if (ber < 0) {
            mentesLabel.setText("A havi bér egész szám legyen, legalább 0.");
            return;
        }

        Dolgozo d = new Dolgozo(nev, reszleg, ber, ujTeljesCheckbox.isSelected());
        try {
            Files.writeString(Path.of(fajlTextField.getText().trim()),
                    d.fajlSor() + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            mentesLabel.setText("Hiba: nem sikerült a fájlba írni.");
            return;
        }
        dolgozok.add(d);
        ujNevTextField.clear();
        ujReszlegTextField.clear();
        ujBerTextField.clear();
        ujTeljesCheckbox.setSelected(false);
        mentesLabel.setText(nev + " sikeresen mentve.");
        onKeresClicked();
    }

    // ---------- Exportálás gomb ----------
    @FXML
    protected void onExportClicked() {
        List<String> sorok = new ArrayList<>();
        for (Dolgozo d : talalatok) sorok.add(d.fajlSor());
        try {
            Files.write(Path.of("export.txt"), sorok, StandardCharsets.UTF_8);
            new Alert(Alert.AlertType.INFORMATION,
                    talalatok.size() + " dolgozó exportálva az export.txt fájlba.").showAndWait();
        } catch (IOException e) {
            new Alert(Alert.AlertType.ERROR, "Az exportálás nem sikerült.").showAndWait();
        }
    }

    // ---------- Előző / Következő ----------
    @FXML
    protected void onElozoClicked() {
        if (index > 0) { index--; frissit(); }
    }

    @FXML
    protected void onKovetkezoClicked() {
        if (index < talalatok.size() - 1) { index++; frissit(); }
    }

    // ---------- Kijelzés frissítése ----------
    private void frissit() {
        int db = talalatok.size();
        keresTalalatLabel.setText(db + " fő");

        if (db == 0) {
            keresNevLabel.setText("Nincs találat");
            kerestalalatLabel.setText("0 / 0");
            keresReszlegLabel.setText("–");
            keresBerLabel.setText("–");
            keresMunkaidoLabel.setText("–");
            keresAtlagBerLabel.setText("–");
            keresLegmagasabbBerLabel.setText("–");
        } else {
            Dolgozo d = talalatok.get(index);
            keresNevLabel.setText(d.getNev());
            kerestalalatLabel.setText((index + 1) + " / " + db);
            keresReszlegLabel.setText(d.getReszleg());
            keresBerLabel.setText(String.format(HU, "%,d Ft", d.getBer()));
            keresMunkaidoLabel.setText(d.isTeljes() ? "Teljes" : "Részmunkaidő");

            double atlag = talalatok.stream().mapToInt(Dolgozo::getBer).average().orElse(0);
            int max = talalatok.stream().mapToInt(Dolgozo::getBer).max().orElse(0);
            keresAtlagBerLabel.setText(String.format(HU, "%,.2f Ft", atlag));
            keresLegmagasabbBerLabel.setText(String.format(HU, "%,d Ft", max));
        }
        elozoButton.setDisable(index <= 0);
        kovetkezoButton.setDisable(index >= db - 1);
    }

    // ---------- Dolgozó osztály (belső osztály, nem kell külön fájl) ----------
    public static class Dolgozo {
        private final String nev;
        private final String reszleg;
        private final int ber;
        private final boolean teljes;

        public Dolgozo(String nev, String reszleg, int ber, boolean teljes) {
            this.nev = nev;
            this.reszleg = reszleg;
            this.ber = ber;
            this.teljes = teljes;
        }

        // Sor formátuma: név;részleg;bér;igen/nem
        public static Dolgozo feldolgoz(String sor) {
            String[] r = sor.split(";");
            String t = r[3].trim().toLowerCase();
            boolean teljes = t.equals("igen") || t.equals("true") || t.equals("1") || t.equals("teljes");
            return new Dolgozo(r[0].trim(), r[1].trim(), Integer.parseInt(r[2].trim()), teljes);
        }

        public String fajlSor() {
            return nev + ";" + reszleg + ";" + ber + ";" + (teljes ? "igen" : "nem");
        }

        public String getNev() { return nev; }
        public String getReszleg() { return reszleg; }
        public int getBer() { return ber; }
        public boolean isTeljes() { return teljes; }
    }
}
module com.example.dolgozokirk {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.dolgozokirk to javafx.fxml;
    exports com.example.dolgozokirk;
}